//
//  ListExerciseDetails.swift
//  Interval Stopwatch
//
//  Created by Dimitri Cunning on 01/06/2024.
//

import SwiftUI

struct ListExerciseDetails: View {
    @Binding var workout: Workout
    @State var exercises: [Exercise] = [
        Exercise(name: "21km run", sets: 1, durationMinutes: 105),
        Exercise(name: "Sprints - 800m", sets: 8, durationMinutes: 1, durationSeconds: 50),
        Exercise(name: "Bench press", sets: 2, reps: 8, metricWeightKg: 100),
        Exercise(name: "Decline leg press", sets: 3, reps: 12, metricWeightKg: 160)
    ]
    
    init(workout: Binding<Workout>) {
        UITableView.appearance().backgroundColor = .black
        self._workout = workout
    }
    
    var body: some View {
        ZStack {
            Color.black.edgesIgnoringSafeArea(.all)
            List {
                ForEach(exercises.indices, id: \.self) { index in
                    HStack {
                        Text(self.exercises[index].name)
                        Spacer()
                        
                        Text("\(self.exercises[index].sets)")
                        Text("x")
                        if let minutes: Int = self.exercises[index].durationMinutes {
                            let seconds: String = self.exercises[index].durationSeconds != nil ? "\(self.exercises[index].durationSeconds!)s" : ""

                            if minutes % 60 == 0 {
                                Text("\(minutes / 60)h \(seconds)")
                            } else if minutes < 60 {
                                Text("\(minutes)m \(seconds)")
                            } else {
                                Text("\(minutes / 60)h \(minutes % 60)m \(seconds)")
                            }
                        } else {
                            Text("\(self.exercises[index].reps ?? 0)")
                        }
                        
                        if self.exercises[index].metricWeightKg > 0 {
                            Text("(\(self.exercises[index].metricWeightKg)kg)")
                        }

                    }.id(UUID())
                }
                .onMove { (indices, newOffset) in
                    self.exercises.move(fromOffsets: indices, toOffset: newOffset)
                }
            }
            .navigationBarTitle(workout.name)
            .navigationBarItems(trailing:
                HStack {
//                    Edtest/merge_request.pyitButton()
//                    Button(action: {
//                        }) {
//                            Text("Edit").font(.title2)
//                                .foregroundColor(.blue)
//                    }
                    Button(action: {
                    }) {
                        Image(systemName: "plus").font(.title2)
                            .foregroundColor(.blue)
                    }
                }
            )
        }
    }
}


class Exercise: ObservableObject {
    @Published var name: String
    @Published var sets: Int
    
    @Published var durationMinutes: Int?
    @Published var durationSeconds: Int?
    @Published var reps: Int?
    
    @Published var metricWeightKg: Int
    
    init(name: String, sets: Int, durationMinutes: Int? = nil, durationSeconds: Int? = nil, reps: Int? = nil, metricWeightKg: Int = 0) {
        self.name = name
        self.sets = sets
        self.durationMinutes = durationMinutes
        self.durationSeconds = durationSeconds
        self.reps = reps
        self.metricWeightKg = metricWeightKg
    }
}



#Preview {
    ContentView()
}
