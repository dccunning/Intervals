//
//  DataBase.swift
//  Interval Stopwatch
//
//  Created by Dimitri Cunning on 02/04/2024.
//

import SwiftUI
import SQLite3

class DataBase {
    var db: OpaquePointer?
    var path: String = "IntervalStopwatch.sqlite"

    init() {
        self.db = openDatabase()
    }
    
    deinit {
        sqlite3_close(self.db)
    }

    func openDatabase() -> OpaquePointer? {
        do {
            let filePath = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false).appendingPathComponent(path)

            var db: OpaquePointer? = nil

            if sqlite3_open(filePath.path, &db) != SQLITE_OK {
                print("error opening or creating db")
                return nil
            } else {
                return db
            }
        } catch {
            print("Error opening or creating database: \(error)")
            return nil
        }
    }

    func selectQuery(_ query: String) -> [[Any]]? {
        var queryStatement: OpaquePointer?
        var results: [[Any]] = []

        // Prepare the query
        if sqlite3_prepare_v2(db, query, -1, &queryStatement, nil) == SQLITE_OK {

            // Fetch rows
            while sqlite3_step(queryStatement) == SQLITE_ROW {
                var row: [Any] = []
                let columnCount = sqlite3_column_count(queryStatement)
                for i in 0..<columnCount {
                    let columnType = sqlite3_column_type(queryStatement, i)

                    switch columnType {
                    case SQLITE_INTEGER:
                        let value = sqlite3_column_int(queryStatement, i)
                        row.append(Int(value))
                    case SQLITE_FLOAT:
                        let value = sqlite3_column_double(queryStatement, i)
                        row.append(Double(value))
                    case SQLITE_TEXT:
                        let value = String(cString: sqlite3_column_text(queryStatement, i))
                        row.append(value)
                    case SQLITE_NULL:
                        row.append("nil")
                    default:
                        row.append("Unknown column type")
                    }
                }
                results.append(row)
            }
        } else {
            print("Query could not be prepared")
        }

        // Finalize the query statement
        sqlite3_finalize(queryStatement)
        return results.isEmpty ? nil : results
    }

    
    func execute(query: String) -> Bool {
        var statement: OpaquePointer?
        
        // Prepare the SQL statement
        guard sqlite3_prepare_v2(db, query, -1, &statement, nil) == SQLITE_OK else {
            let errorMessage = String(cString: sqlite3_errmsg(db))
            print("Error preparing statement: \(errorMessage)")
            return false
        }
        
        // Execute the SQL statement
        let result = sqlite3_step(statement)
        if result != SQLITE_DONE {
            let errorMessage = String(cString: sqlite3_errmsg(db))
            print("Error executing statement: \(errorMessage)")
            sqlite3_finalize(statement)
            return false
        }
        
        sqlite3_finalize(statement)
        return true
    }
    
    func createWorkoutTable(){
        let createTableQuery = """
        CREATE TABLE IF NOT EXISTS Workouts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            durationMinutes INTEGER,
            color TEXT,
            chunkSize INTEGER,
            LastCompletedTimestamp TIMESTAMP
        );
        """
        if self.execute(query: createTableQuery) {
            print("Workouts table created (or exists) successfully.")
        } else {
            print("Error creating WorkoutsCompleted table.")
        }
    }
    
    func insertWorkoutTableRow(name: String, hours: Int, minutes: Int, selectedColor: ColorSelection, chunkSize: Int) -> Bool {
        let insertQuery = "INSERT INTO Workouts (name, durationMinutes, color, chunkSize) VALUES ('\(name)', \(Int(hours * 60 + minutes)), '\(selectedColor.displayName)', \(chunkSize))"
        return self.execute(query: insertQuery)
    }
    
    func fetchWorkoutTableRows() -> [Workout] {
        var workouts: [Workout] = []

        let query = "SELECT id, name, durationMinutes, color, chunkSize, LastCompletedTimestamp FROM Workouts"
        var statement: OpaquePointer?

        if sqlite3_prepare_v2(db, query, -1, &statement, nil) == SQLITE_OK {
            while sqlite3_step(statement) == SQLITE_ROW {
                let id = Int(sqlite3_column_int(statement, 0))
                let name = String(cString: sqlite3_column_text(statement, 1))
                let durationMinutes = Int(sqlite3_column_int(statement, 2))
                let color = String(cString: sqlite3_column_text(statement, 3))
                let chunkSize = Int(sqlite3_column_int(statement, 4))
                
                var lastCompletedTimestamp: Date?
                if let timestampCString = sqlite3_column_text(statement, 5) {
                    let timestampString = String(cString: timestampCString)
                    let dateFormatter = DateFormatter()
                    dateFormatter.timeZone = TimeZone(identifier: "UTC")
                    dateFormatter.dateFormat = "yyyy-MM-dd"
                    if let date = dateFormatter.date(from: timestampString) {
                        lastCompletedTimestamp = date
                    } else {
                        lastCompletedTimestamp = nil
                    }
                } else {
                    lastCompletedTimestamp = nil
                }

                let workout = Workout(id: id, name: name, durationMinutes: durationMinutes, color: color, chunkSize: chunkSize, lastCompletedTimestamp: lastCompletedTimestamp)
                workouts.append(workout)
            }
            sqlite3_finalize(statement)
        } else {
            print("Error preparing query: fetchWorkoutTableRows")
        }

        return workouts
    }
    
    func createWorkoutsCompletedTable() {
        let dateTimeFormatter = DateFormatter()
        dateTimeFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        dateTimeFormatter.timeZone = TimeZone(identifier: "UTC")
        let updatedTimestamp = dateTimeFormatter.string(from: Date())
        let createTableQuery = """
        CREATE TABLE IF NOT EXISTS WorkoutsCompleted (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            workoutId INTEGER,
            markedForDate TIMESTAMP,
            completed BOOL,
            updatedTimestamp TIMESTAMP DEFAULT '\(updatedTimestamp)',
            UNIQUE(markedForDate, workoutId)
        );
        """
        
        if self.execute(query: createTableQuery) {
            print("WorkoutsCompleted table created (or exists) successfully.")
        } else {
            print("Error creating WorkoutsCompleted table.")
        }
    }
    
    func toggleOrInsertWorkoutCompletedTableRow(workoutId: Int, markedForDate: Date) -> Bool {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        dateFormatter.timeZone = TimeZone(identifier: "UTC")
        
        let dateTimeFormatter = DateFormatter()
        dateTimeFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        dateTimeFormatter.timeZone = TimeZone(identifier: "UTC")
        let updatedTimestamp = dateTimeFormatter.string(from: Date())
        let formattedDate = dateFormatter.string(from: markedForDate)
        
        // Check if the row exists
        let checkQuery = """
        SELECT id, completed
        FROM WorkoutsCompleted
        WHERE workoutId = \(workoutId) AND markedForDate = '\(formattedDate)';
        """
        
        if let result = selectQuery(checkQuery), !result.isEmpty, !result[0].isEmpty {
            if let firstRow = result.first, result.count > 0 {
                let currentCompleted = firstRow[1] as? Int == 1
                let toggleCompleted = !currentCompleted

                let updateQuery = """
                UPDATE WorkoutsCompleted
                SET completed = \(toggleCompleted ? 1 : 0), updatedTimestamp = '\(updatedTimestamp)'
                WHERE workoutId = \(workoutId) AND markedForDate = '\(formattedDate)';
                """
                return self.execute(query: updateQuery)
            } else {
                print("Incorrect result data")
                return false
            }
        } else {
            let insertQuery = """
            INSERT INTO WorkoutsCompleted (workoutId, markedForDate, completed)
            VALUES (\(workoutId), '\(formattedDate)', 1);
            """
            return self.execute(query: insertQuery)
        }
    }
    
    func workoutIsCompletedOnDate(workoutId: Int, date: Date) -> Bool {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        dateFormatter.timeZone = TimeZone(identifier: "UTC")
        let formattedDate = dateFormatter.string(from: date)
        let query = """
        SELECT id
        FROM WorkoutsCompleted
        WHERE workoutId = \(workoutId) AND markedForDate = '\(formattedDate)' AND completed;
        """
        var statement: OpaquePointer?

        if sqlite3_prepare_v2(self.db, query, -1, &statement, nil) == SQLITE_OK {
            let result = sqlite3_step(statement)

            if result == SQLITE_ROW {
                sqlite3_finalize(statement)
                return true
            }
        } else {
            let errorMessage = String(cString: sqlite3_errmsg(self.db))
            print("Error preparing query: workoutIsCompletedOnDate - \(errorMessage)")
        }

        sqlite3_finalize(statement)
        return false
    }
    
    func fetchWorkoutsCompletedTableRows(condition: String = "", dateSince: String) -> [WorkoutsCompleted] {
        var markedWorkoutsCompleted: [WorkoutsCompleted] = []

        let query = """
        SELECT wc.id, wc.workoutId, wc.markedForDate, wc.completed, w.color, w.chunkSize, (julianday(wc.markedForDate) - julianday(strftime('%Y-%m-%d', 'now', 'localtime')) + 14) AS indexDate, strftime('%Y-%m-%d %H:%M:%S', 'now', 'localtime') as currentDatetime, wc.updatedTimestamp
        FROM WorkoutsCompleted wc
        JOIN Workouts w ON wc.workoutId = w.id 
        WHERE markedForDate > '\(dateSince)' AND completed
        ORDER BY wc.updatedTimestamp DESC;
        """

        var statement: OpaquePointer?
        
        if sqlite3_prepare_v2(self.db, query, -1, &statement, nil) == SQLITE_OK {
            while sqlite3_step(statement) == SQLITE_ROW {
                let dateFormatter = DateFormatter()
                let dateTimeFormatter = DateFormatter()
                dateTimeFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
                dateTimeFormatter.timeZone = TimeZone(identifier: "UTC")
                dateFormatter.dateFormat = "yyyy-MM-dd"
                dateFormatter.timeZone = TimeZone(identifier: "UTC")
                
                let id = Int(sqlite3_column_int(statement, 0))
                let workoutId = Int(sqlite3_column_int(statement, 1))
                let timestampString = String(cString: sqlite3_column_text(statement, 2))
                let completed = sqlite3_column_int(statement, 3) == 1 ? true : false
                let color = String(cString: sqlite3_column_text(statement, 4)!)
                let chunkSize = Int(sqlite3_column_int(statement, 5))
                let indexDate = Int(sqlite3_column_int(statement, 6))
                let currentDatetime = dateTimeFormatter.date(from: String(cString: sqlite3_column_text(statement, 7)))
                let updatedTimestamp = String(cString: sqlite3_column_text(statement, 8))
                
                if let converted = dateTimeFormatter.date(from: updatedTimestamp) {
                    print("Success converting to date: \(converted)")
                } else {
                    print("Failed to convert string to date: \(updatedTimestamp)")
                }
                
                if let markedForDate = dateFormatter.date(from: timestampString), let updatedTimestamp = dateTimeFormatter.date(from: updatedTimestamp) {
                    let workoutCompleted = WorkoutsCompleted(id: id, workoutId: workoutId, markedForDate: markedForDate, completed: completed, updatedTimestamp: updatedTimestamp, color: color, chunkSize: chunkSize, indexDate: indexDate, currentDatetime: currentDatetime)
                    markedWorkoutsCompleted.append(workoutCompleted)
                } else {
                    print("Failed to convert timestamp string to Date (timestampString: \(timestampString)) (updatedTimestamp: \(updatedTimestamp))")
                }
                
            }
            sqlite3_finalize(statement)
        } else {
            print("Error preparing query: fetchWorkoutsCompletedTableRows")
        }
        return markedWorkoutsCompleted
    }
    
    func updateWorkoutLastCompletedTimestamp(workoutId: Int) -> Date? {
        let markedForDate = """
        SELECT max(markedForDate) as date
        FROM WorkoutsCompleted
        WHERE workoutId = \(workoutId) AND completed = 1;
        """
        var updateQuery: String
        
        if let result = DataBase().selectQuery(markedForDate),
           !result.isEmpty,
           !result[0].isEmpty,
           let firstRow = result.first,
           let currentCompleted = firstRow.first as? String {
            updateQuery = """
                UPDATE Workouts
                SET LastCompletedTimestamp = '\(currentCompleted)'
                WHERE id = \(workoutId);
                """
        } else {
            updateQuery = """
                UPDATE Workouts
                SET LastCompletedTimestamp = NULL
                WHERE id = \(workoutId);
                """
        }
        
        if self.execute(query: updateQuery) {
        } else {
            print("Error updating LastCompletedTimestamp")
        }
        
        let query = """
        SELECT LastCompletedTimestamp
        FROM Workouts
        WHERE id = \(workoutId);
        """
        var queryStatement: OpaquePointer?

        // Prepare the query
        if sqlite3_prepare_v2(db, query, -1, &queryStatement, nil) == SQLITE_OK {
            defer {
                // Finalize the statement to release resources
                sqlite3_finalize(queryStatement)
            }

            // Step through the query result
            if sqlite3_step(queryStatement) == SQLITE_ROW {
                // Retrieve the date string from the query result
                if let dateString = sqlite3_column_text(queryStatement, 0) {
                    let dateStr = String(cString: dateString)

                    // Convert the string date to a Date object
                    let dateFormatter = DateFormatter()
                    dateFormatter.dateFormat = "yyyy-MM-dd"
                    dateFormatter.timeZone = TimeZone(identifier: "UTC")
                    if let date = dateFormatter.date(from: dateStr) {
                        return date
                    } else {
                        print("Error: Unable to parse date string.")
                        return nil
                    }
                } else {
                    // No result found
                    return nil
                }
            }
        } else {
            let errorMessage = String(cString: sqlite3_errmsg(db))
            print("Error preparing statement: \(errorMessage)")
        }
        return nil
    }
    
}
